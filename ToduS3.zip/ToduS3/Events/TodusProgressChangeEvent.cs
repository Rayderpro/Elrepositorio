﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDS3.Events
{
    public class TodusProgressChangeEvent : EventArgs
    {
        public int Progres { get; private set; }

        public long CurrenSize { get; set; } = 0;

        public long MaxSize { get; set; } = 0;

        internal void UpdateProgres()
        {

        }
    }
}
