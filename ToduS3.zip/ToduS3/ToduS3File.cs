﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDS3
{
    public class ToduS3File
    {
        public List<Tuple<string, string>> Items { get; private set; } = new List<Tuple<string, string>>();

        public int Lenght => Items.Count;

        private int _index = 0;

        public bool IsFinalStack
        {
            get
            {
                return _index >= Lenght;
            }
        }

        public void Add(string name,string url)
        {
            Items.Add(new Tuple<string, string>(name, url));
        }

        public string Get(string name)
        {
            string ret = string.Empty;
            foreach (var i in Items)
            {
                if (i.Item1 == name)
                {
                    ret = i.Item2;
                    break;
                }
            }
            return ret;
        }

        public void Step()
        {
            if (_index < (Lenght-1))
                _index++;
        }
        public string[] Pop()
        {
            return new string[] {
                Items[_index].Item1,
                Items[_index].Item2,
            };
        }

        public static ToduS3File FromFile(string path)
        {
            ToduS3File ret = null;
            if (File.Exists(path)) {
                ret = new ToduS3File();
                string[] lines = File.ReadAllLines(path);
                foreach (var lin in lines)
                {
                    string name = lin.Split('\t')[1];
                    string url = lin.Split('\t')[0];
                    ret.Add(name, url);
                }
            }
            return ret;
        }
    }

}
