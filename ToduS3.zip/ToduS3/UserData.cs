﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDS3
{
    public class UserData
    {
        public int exp { get; set; } = 0;
        public string username { get; set; } = "";
        public int version { get; set; } = 0;
    }
}
