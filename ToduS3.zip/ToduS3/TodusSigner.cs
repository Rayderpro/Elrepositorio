﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace TDS3
{
    public delegate void TodusSignerComplete(TodusSigner sender, TodusSignerData signer);
    public struct TodusSignerData
    {
        public string BaseUrl { get; set; }
        public string SignerUrl { get; set; }
        public bool IsSignerSussesfull { get; set; }
        public TodusStatus Status { get; set; }
    }
   
    public class TodusSigner : TodusBase
    {
        private string _todustoken;
        private string _todusurl;
        private string _sid;
        private TodusSignerComplete _oncomplete;
        private TodusSignerData _signerdata;

        public TodusSigner(string token,string todusurl)
        {
            _todustoken = token;
            _todusurl = todusurl;
        }

        public void StartSigner(TodusSignerComplete onComplete)
        {
            _sid = GenerateSessionID();
            _signerdata = new TodusSignerData();
            _signerdata.Status = TodusStatus.NotAuthorized;
            _oncomplete = onComplete;
            _socket = new TcpClient();
            _socket.BeginConnect(HOST,PORT,new AsyncCallback(OnConnect),null);
        }

        private void OnConnect(IAsyncResult ar)
        {
            try {
                _socket.EndConnect(ar);
                _sslstream = new SslStream(_socket.GetStream(), true, new RemoteCertificateValidationCallback((s, c, ch, err) =>
                {
                    if (err == SslPolicyErrors.None)
                        return true;
                    return false;
                }), null);
                _sslstream.AuthenticateAsClient(HOST);
                _asynbuff = new byte[BUFF_SIZE];
                _sslstream.BeginRead(_asynbuff, 0, _asynbuff.Length, new AsyncCallback(OnDataReceiv), null);
                SendData("<stream:stream xmlns='jc' o='im.todus.cu' xmlns:stream='x1' v='1.0'>");
            }
            catch
            {
                _signerdata.BaseUrl = _todusurl;
                _signerdata.SignerUrl = "";
                _signerdata.IsSignerSussesfull = false;
                _signerdata.Status = TodusStatus.ConnectionError;
                CloseConnection();
                if (_oncomplete != null)
                    _oncomplete(this, _signerdata);
            }
        }

        private void OnDataReceiv(IAsyncResult ar)
        {
            try
            {
                int read = _sslstream.EndRead(ar);
                if (read > 0)
                {
                    byte[] readBuff = new byte[read];
                    Array.Copy(_asynbuff, 0, readBuff, 0, read);
                    HandleData(readBuff);
                }
                _sslstream.BeginRead(_asynbuff, 0, _asynbuff.Length, new AsyncCallback(OnDataReceiv), null);
            }
            catch
            {
                _signerdata.BaseUrl = _todusurl;
                _signerdata.SignerUrl = "";
                _signerdata.IsSignerSussesfull = false;
                _signerdata.Status = TodusStatus.ThrowError;
                CloseConnection();
                if (_oncomplete != null)
                    _oncomplete(this,_signerdata);
            }
        }

        private void HandleData(byte[] readBuff)
        {
            string str = Encoding.UTF8.GetString(readBuff);
            if (str == "<stream:features><es xmlns='x2'><e>PLAIN</e><e>X-OAUTH2</e></es><register xmlns='http://jabber.org/features/iq-register'/></stream:features>")
            {
                string signed = GetSignedToken(_todustoken);
                SendData("<ah xmlns='ah:ns' e='PLAIN'>" + signed + "</ah>");
            }
            else if (str == "<ok xmlns='x2'/>")
            {
                SendData("<stream:stream xmlns='jc' o='im.todus.cu' xmlns:stream='x1' v='1.0'>");
            }
            else if (str.Contains("<stream:features><b1 xmlns='x4'/>"))
            {
                SendData("<iq i='" + _sid + "-1' t='set'><b1 xmlns='x4'></b1></iq>");
            }
            else if (str.Contains("t='result' i='" + _sid + "-1'>"))
            {
                SendData("<iq i='" + _sid + "-2' t='get'><query xmlns='todus:gurl' url='" + _todusurl + "'></query></iq>");
            }
            else if (str.Contains("t='result' i='" + _sid + "-2'>") & str.Contains("status='200'"))
            {
                string[] tokens = str.Split(' ');
                string SignedUrl = tokens[5].Replace("du='", "").Replace("'", "").Replace("amp;", "");
                _signerdata.BaseUrl = _todusurl;
                _signerdata.SignerUrl = SignedUrl;
                _signerdata.IsSignerSussesfull = true;
                _signerdata.Status = TodusStatus.Signed;
                CloseConnection();
                if (_oncomplete != null)
                    _oncomplete(this, _signerdata);
            }
            else if (str == "<failure xmlns='x2'><not-authorized/><text xml:lang='en'>Invalid username or password</text></failure>")
            {
                _signerdata.BaseUrl = _todusurl;
                _signerdata.SignerUrl = "";
                _signerdata.IsSignerSussesfull = false;
                _signerdata.Status = TodusStatus.NotAuthorized;
                CloseConnection();
                if (_oncomplete != null)
                    _oncomplete(this, _signerdata);
            }
        }
    }
}
