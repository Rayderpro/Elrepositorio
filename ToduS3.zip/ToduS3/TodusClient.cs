﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TDS3.Events;

namespace TDS3
{
    public delegate void TodusProgressChanged(TodusClient sender, TodusProgressChangeEvent ev);
    public delegate void TodusCompleteTask(TodusClient sender, TodusCompleteTaskEvent ev);

    public class TodusClient
    {

        public const string Host = "s3.todus.cu";
        public const string UploadUserAgent = "ToDus 0.39.4 HTTP-Upload";
        public const string DownloadUserAgent = "ToDus 0.39.4 HTTP-Download";
        public const string AcceptEncoding = "gzip";
        public const string UploadContentType = "application/octet-stream";

        public UserData User { get; private set; }

        private string _token = "";


        public TodusClient(string token)
        {
            _token = token;
            User = TodusBase.GetUserData(_token);
        }


        public void DownloadTask(string path,ToduS3File s3file,TodusProgressChanged progresChangedFunc, TodusCompleteTask completeFunc)
        {
           
        }

    }

}
