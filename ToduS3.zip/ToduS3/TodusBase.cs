﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using ToduS3.Utils;

namespace TDS3
{
    public abstract class TodusBase
    {
       public const string HOST = "im.todus.cu";
       public const int PORT = 1756;
        public const int BUFF_SIZE = 4096;


        protected byte[] _asynbuff;
        protected SslStream _sslstream;
        protected TcpClient _socket;

        
        public static string GetPhoneFromToken(string token)
        {
            string base64 = token.Split('.')[1];
            byte[] encodeBytes = Convert.FromBase64String(base64);
            string data = Encoding.UTF8.GetString(encodeBytes);
            return JsonConvert.Deserialize<UserData>(data).username;
        }

        public static UserData GetUserData(string token)
        {
            string base64 = token.Split('.')[1];
            byte[] encodeBytes = Convert.FromBase64String(base64);
            string data = Encoding.UTF8.GetString(encodeBytes);
            return JsonConvert.Deserialize<UserData>(data);
        }

        public static string GetSignedToken(string token)
        {
            string Phone = GetPhoneFromToken(token);
            string char0 = Convert.ToChar(0).ToString();
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(char0 + Phone + char0 + token));
        }

        public static string GenerateSessionID()
        {
            string charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            string newSid = "";
            Random rnd = new Random(Environment.TickCount);
            for (int i = 0; i < 5; i++)
                newSid += $"{charset[rnd.Next(0, charset.Length)]}";
            return newSid;
        }

        public void SendData(string text)
        {
            if (_sslstream != null)
            {
                byte[] data = Encoding.UTF8.GetBytes(text);
                _sslstream.BeginWrite(data, 0, data.Length, (ar) =>
                {
                    _sslstream.EndWrite(ar);
                }, null);
            }
        }

        public void CloseConnection()
        {
            _sslstream?.Close();
            _sslstream = null;
            _socket?.Close();
            _socket = null;
        }
    }
}
